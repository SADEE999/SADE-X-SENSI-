# SADEE X DIMA OPTIMIZER V2

This repository contains the Android app and the separate Supabase admin dashboard.

## Included
- Android Java app
- Supabase license-key validation
- Plans: 7 Days (LKR 500), 1 Month (LKR 1,000), Lifetime (LKR 2,200)
- Admin dashboard under `admin-dashboard/`
- GitHub Actions workflow under `.github/workflows/main.yml`

## GitHub Actions
The workflow does two jobs:
1. Builds the Android debug APK with **Java 17 + Gradle 8.0** and uploads it as `SADEE-X-DIMA-APK`.
2. Deploys `admin-dashboard/` to GitHub Pages.

Before the first Pages deployment, set:
`Repository Settings -> Pages -> Build and deployment -> Source -> GitHub Actions`.

## Supabase
1. Run `supabase.sql` in the Supabase SQL Editor.
2. Create the admin user in Supabase Authentication.
3. Add that user's id/email to `public.admin_users` using the final SQL statement.
4. Keep only the publishable key in frontend code. Never put a service-role/secret key in the app or dashboard.
