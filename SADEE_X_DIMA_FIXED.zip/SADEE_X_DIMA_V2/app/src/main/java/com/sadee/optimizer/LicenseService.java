package com.sadee.optimizer;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class LicenseService {
    public interface Callback { void onResult(boolean ok, String message, JSONObject data); }
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    public static void validate(String key, String deviceId, Callback callback) {
        EXECUTOR.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(SupabaseConfig.URL + "/rest/v1/rpc/validate_license");
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000);
                c.setReadTimeout(10000);
                c.setDoOutput(true);
                c.setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY);
                c.setRequestProperty("Authorization", "Bearer " + SupabaseConfig.PUBLISHABLE_KEY);
                c.setRequestProperty("Content-Type", "application/json");
                JSONObject body = new JSONObject();
                body.put("p_key", key);
                body.put("p_device_id", deviceId);
                try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                int code = c.getResponseCode();
                BufferedReader br = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
                StringBuilder out = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) out.append(line);
                JSONObject data = out.length() == 0 ? new JSONObject() : new JSONObject(out.toString());
                boolean ok = code >= 200 && code < 300 && data.optBoolean("valid", false);
                String msg = data.optString("message", ok ? "License verified." : "License is not valid.");
                callback.onResult(ok, msg, data);
            } catch (Exception e) {
                callback.onResult(false, "Connection error: " + e.getMessage(), new JSONObject());
            } finally { if (c != null) c.disconnect(); }
        });
    }
}
