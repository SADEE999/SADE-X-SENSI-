package com.sadee.optimizer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {
    private EditText keyInput;
    private TextView status;
    private String selectedPlan = "7 Days";
    private String selectedPrice = "LKR 500";
    private static final String WHATSAPP = "94768472404";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        keyInput = findViewById(R.id.keyInput); status = findViewById(R.id.txtStatus);
        Button login = findViewById(R.id.btnLogin), order = findViewById(R.id.btnOrder);
        Button p7 = findViewById(R.id.plan7), p30 = findViewById(R.id.plan30), pl = findViewById(R.id.planLife);
        p7.setOnClickListener(v -> { selectedPlan="7 Days"; selectedPrice="LKR 500"; status.setText("Selected: 7 Days • LKR 500"); });
        p30.setOnClickListener(v -> { selectedPlan="1 Month"; selectedPrice="LKR 1,000"; status.setText("Selected: 1 Month • LKR 1,000"); });
        pl.setOnClickListener(v -> { selectedPlan="Lifetime"; selectedPrice="LKR 2,200"; status.setText("Selected: Lifetime • LKR 2,200"); });
        order.setOnClickListener(v -> openWhatsApp());
        login.setOnClickListener(v -> verify());
        String saved = getSharedPreferences("license", MODE_PRIVATE).getString("key", "");
        if (!saved.isEmpty()) { keyInput.setText(saved); verify(); }
    }

    private void verify() {
        String key = keyInput.getText().toString().trim().toUpperCase();
        if (key.isEmpty()) { status.setText("Enter your license key."); return; }
        status.setText("VERIFYING LICENSE…");
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        LicenseService.validate(key, deviceId, new LicenseService.Callback() {
            @Override public void onResult(boolean ok, String message, JSONObject data) {
                runOnUiThread(() -> {
                    if (ok) {
                        getPreferences(0).edit().putString("last_key", key).apply();
                        getSharedPreferences("license", MODE_PRIVATE).edit().putString("key", key).apply();
                        startActivity(new Intent(LoginActivity.this, MainActivity.class)); finish();
                    } else status.setText(message);
                });
            }
        });
    }

    private void openWhatsApp() {
        String msg = "SADEE X DIMA OPTIMIZER%0A%0AI want to order:%0APlan: " + Uri.encode(selectedPlan) + "%0APrice: " + Uri.encode(selectedPrice) + "%0A%0APlease send payment/order details.";
        Uri uri = Uri.parse("https://wa.me/" + WHATSAPP + "?text=" + msg);
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception e) { status.setText("WhatsApp link could not be opened."); }
    }
}
