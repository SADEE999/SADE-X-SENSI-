package com.sadee.optimizer;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        TabLayout tabs=findViewById(R.id.tabLayout); ViewPager2 pager=findViewById(R.id.viewPager);
        pager.setAdapter(new FragmentStateAdapter(this){
            @NonNull @Override public Fragment createFragment(int p){
                switch(p){case 0:return new Page1ScannerFragment();case 1:return new Page2CleanerFragment();case 2:return new Page3SaverFragment();case 3:return new Page4GfxFragment();default:return new Page5InjectorFragment();}}
            @Override public int getItemCount(){return 5;}
        });
        String[] titles={"SCAN","CLEAN","POWER","GFX","GAME"};
        new TabLayoutMediator(tabs,pager,(t,p)->t.setText(titles[p])).attach();
    }
    @Override protected void onResume(){ super.onResume(); if(getSharedPreferences("license",MODE_PRIVATE).getString("key","").isEmpty()) { finish(); } }
}
