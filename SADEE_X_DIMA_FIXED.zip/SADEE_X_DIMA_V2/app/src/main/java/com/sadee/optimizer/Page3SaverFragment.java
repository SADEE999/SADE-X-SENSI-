package com.sadee.optimizer;
import android.content.*;import android.os.*;import android.view.*;import android.widget.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class Page3SaverFragment extends Fragment{
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){View v=i.inflate(R.layout.fragment_page3,c,false);Button p=v.findViewById(R.id.btnUltraMode),r=v.findViewById(R.id.btnCpuCooler);p.setOnClickListener(x->Toast.makeText(getContext(),"Power profile guidance enabled",Toast.LENGTH_SHORT).show());r.setOnClickListener(x->{BatteryManager bm=(BatteryManager)requireContext().getSystemService(Context.BATTERY_SERVICE);int pct=bm!=null?bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY):-1;Toast.makeText(getContext(),"Battery: "+pct+"%",Toast.LENGTH_SHORT).show();});return v;}
}
