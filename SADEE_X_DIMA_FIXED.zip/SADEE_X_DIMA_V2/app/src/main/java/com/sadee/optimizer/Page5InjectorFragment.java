package com.sadee.optimizer;
import android.content.*;import android.view.*;import android.widget.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class Page5InjectorFragment extends Fragment{
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){View v=i.inflate(R.layout.fragment_page5,c,false);Button go=v.findViewById(R.id.btnInjector);TextView st=v.findViewById(R.id.txtGameStatus);go.setOnClickListener(x->{String pkg="com.dts.freefireth";Intent launch=requireContext().getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null){st.setText("GAME READY\nLaunching Free Fire…");startActivity(launch);}else st.setText("Free Fire is not installed on this device.");});return v;}
}
