package com.sadee.optimizer;

public final class SupabaseConfig {
    public static final String URL = "https://cpmzjplfqggmgeotmtcd.supabase.co";
    public static final String PUBLISHABLE_KEY = "sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW";
    private SupabaseConfig() {}
}
