-- SADEE X DIMA OPTIMIZER V2
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key text unique not null,
  plan text not null check (plan in ('7 Days','1 Month','Lifetime')),
  price_lkr integer not null check (price_lkr >= 0),
  status text not null default 'unused' check (status in ('unused','active','paused','expired')),
  device_id text,
  created_at timestamptz not null default now(),
  activated_at timestamptz,
  expires_at timestamptz
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid());
$$;

create or replace function public.validate_license(p_key text, p_device_id text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare r public.licenses;
begin
  select * into r from public.licenses where upper(license_key)=upper(trim(p_key)) limit 1;
  if not found then return jsonb_build_object('valid',false,'message','License key not found.'); end if;
  if r.status = 'paused' then return jsonb_build_object('valid',false,'message','License is '||r.status||'.'); end if;
  if r.expires_at is not null and r.expires_at < now() then
    update public.licenses set status='expired' where id=r.id;
    return jsonb_build_object('valid',false,'message','License has expired.');
  end if;
  if r.device_id is not null and r.device_id <> p_device_id then return jsonb_build_object('valid',false,'message','License is already bound to another device.'); end if;
  if r.device_id is null then
    update public.licenses set status='active', device_id=p_device_id, activated_at=coalesce(activated_at,now()), expires_at=case when plan='7 Days' then coalesce(expires_at,now()+interval '7 days') when plan='1 Month' then coalesce(expires_at,now()+interval '30 days') else null end where id=r.id returning * into r;
  end if;
  return jsonb_build_object('valid',true,'message','License verified.','plan',r.plan,'expires_at',r.expires_at,'status',r.status);
end;
$$;

alter table public.licenses enable row level security;
alter table public.admin_users enable row level security;

revoke all on public.licenses from anon, authenticated;
revoke all on public.admin_users from anon, authenticated;
grant execute on function public.validate_license(text,text) to anon, authenticated;
grant select,insert,update,delete on public.licenses to authenticated;
grant select on public.admin_users to authenticated;

drop policy if exists "admin read licenses" on public.licenses;
drop policy if exists "admin insert licenses" on public.licenses;
drop policy if exists "admin update licenses" on public.licenses;
drop policy if exists "admin delete licenses" on public.licenses;
create policy "admin read licenses" on public.licenses for select to authenticated using (public.is_admin());
create policy "admin insert licenses" on public.licenses for insert to authenticated with check (public.is_admin());
create policy "admin update licenses" on public.licenses for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin delete licenses" on public.licenses for delete to authenticated using (public.is_admin());

-- After creating your admin account in Supabase Authentication, replace the email below and run:
-- insert into public.admin_users(user_id,email) select id,email from auth.users where email='YOUR_ADMIN_EMAIL';
