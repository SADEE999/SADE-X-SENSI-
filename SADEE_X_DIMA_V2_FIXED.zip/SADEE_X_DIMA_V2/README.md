# SADEE X DIMA OPTIMIZER V2

Includes:
- Android Java optimizer app based on the supplied project.
- License-key login backed by Supabase RPC.
- Plans: 7 Days LKR 500, 1 Month LKR 1,000, Lifetime LKR 2,200.
- WhatsApp order button for +94 76 847 2404.
- Separate responsive Supabase admin dashboard matching the supplied screenshots: stats, generator, plan overview, search/filter, activate/pause/expire/delete.
- GitHub Pages Actions workflow for the admin dashboard.

## Supabase setup
1. Open Supabase SQL Editor and run `supabase.sql`.
2. Create an admin account under Authentication > Users.
3. Run the final `insert into public.admin_users(...)` statement from `supabase.sql` with that account's email.
4. Put the repository's `admin-dashboard` folder on GitHub Pages. The included workflow deploys it from the `main` branch.

The Android app and admin dashboard contain only the Supabase publishable key. Do not put a service-role/secret key in either frontend.

## Notes
The gaming tools are device-safe utility functions: device diagnostics, cleanup requests, battery/display/network status and game launching. The app does not inject or modify game memory.
